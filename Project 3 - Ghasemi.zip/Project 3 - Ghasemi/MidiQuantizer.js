
class MidiQuantizer {
    constructor () {
        this.recordedNotes = [];
        this.isPlayingBack = false;
    }
initialize () {
    WebMidi.enable ((err) => {
        if (err) {
            console.error ("WebMidi could not be enabled.", err);
            return;
        }
        this.inputOutput ();
    })
}
}